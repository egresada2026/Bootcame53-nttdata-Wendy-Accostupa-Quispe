package com.nttdata.bank.products.api;

import com.nttdata.bank.products.domain.Product;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ProductsApi {

    Mono<ResponseEntity<Product>> addProduct(Mono<Product> product, ServerWebExchange exchange);
    Mono<ResponseEntity<Product>> getProductById(String id, ServerWebExchange exchange);
    Mono<ResponseEntity<Flux<Product>>> getProducts(ServerWebExchange exchange);
}


